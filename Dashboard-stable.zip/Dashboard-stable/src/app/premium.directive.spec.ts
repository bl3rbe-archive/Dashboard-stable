import { PremiumDirective } from '../directives/premium.directive';

describe('PremiumDirective', () => {
  it('should create an instance', () => {
    const directive = new PremiumDirective();
    expect(directive).toBeTruthy();
  });
});
