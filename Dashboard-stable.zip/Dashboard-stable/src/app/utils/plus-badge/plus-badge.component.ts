import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plus-badge',
  templateUrl: './plus-badge.component.html',
  styleUrls: ['./plus-badge.component.css']
})
export class PlusBadgeComponent {}
