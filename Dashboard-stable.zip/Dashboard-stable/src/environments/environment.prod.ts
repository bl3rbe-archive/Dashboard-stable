export const environment = {
  botOwnerId: '218459216145285121',
  discordInvite: 'https://discord.gg/24tycau',
  endpoint: '/api',
  githubURL: 'https://github.com/theADAMJR/2PG-Dashboard',
  production: true,
  docsURL: 'https://docs.2pg.xyz',
  stripePublicKey: 'pk_live_Y4fYfqvEgZNsllNFo4TeFcmv005D0tNBWQ',
  version: 'v0.3.2b'
};
